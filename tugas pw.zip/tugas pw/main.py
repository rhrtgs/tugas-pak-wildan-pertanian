from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.popup import Popup
from kivy.uix.label import Label

from kivymd.app import MDApp
from kivymd.uix.pickers import MDDatePicker

from database import connect_db


# =====================================
# SESSION
# =====================================

current_user_id = None
current_username = ""


# =====================================
# POPUP
# =====================================

def show_popup(title, message):

    popup = Popup(
        title=title,
        content=Label(text=message),
        size_hint=(0.7, 0.3)
    )

    popup.open()


# =====================================
# LOGIN
# =====================================

class LoginScreen(Screen):

    def do_login(self):

        global current_user_id
        global current_username

        username = self.ids.username.text.strip()
        password = self.ids.password.text.strip()

        if username == "" or password == "":
            show_popup("Error", "Username dan password wajib diisi")
            return

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        SELECT * FROM users
        WHERE username=%s AND password=%s
        """

        cursor.execute(query, (username, password))

        user = cursor.fetchone()

        conn.close()

        if user:

            current_user_id = user[0]
            current_username = user[1]

            show_popup("Sukses", "Login berhasil")

            self.manager.current = "dashboard"

        else:
            show_popup("Error", "Username/password salah")


# =====================================
# REGISTER
# =====================================

class RegisterScreen(Screen):

    def register_user(self):

        username = self.ids.reg_username.text.strip()
        password = self.ids.reg_password.text.strip()
        nama = self.ids.reg_nama.text.strip()

        if username == "" or password == "" or nama == "":
            show_popup("Error", "Semua field wajib diisi")
            return

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        INSERT INTO users
        (username, password, nama)
        VALUES (%s,%s,%s)
        """

        try:

            cursor.execute(query, (
                username,
                password,
                nama
            ))

            conn.commit()

            show_popup("Sukses", "Register berhasil")

            self.manager.current = "login"

        except:
            show_popup("Error", "Username sudah digunakan")

        conn.close()


# =====================================
# DASHBOARD
# =====================================

class DashboardScreen(Screen):

    def on_enter(self):

        conn = connect_db()
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM lahan")
        total_lahan = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM kegiatan")
        total_kegiatan = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM konsultasi")
        total_konsultasi = cursor.fetchone()[0]

        self.ids.statistik.text = f"""
Total Lahan      : {total_lahan}

Total Kegiatan   : {total_kegiatan}

Total Konsultasi : {total_konsultasi}
"""

        conn.close()

    def logout(self):

        global current_user_id
        global current_username

        current_user_id = None
        current_username = ""

        self.manager.current = "login"


# =====================================
# PROFIL
# =====================================

class ProfilScreen(Screen):

    def on_enter(self):
        self.tampil_user()

    def kembali(self):
        self.manager.current = "dashboard"

    def tampil_user(self):

        global current_user_id

        conn = connect_db()
        cursor = conn.cursor()

        query = "SELECT * FROM users WHERE id=%s"

        cursor.execute(query, (current_user_id,))

        user = cursor.fetchone()

        conn.close()

        if user:

            self.ids.id_user.text = str(user[0])
            self.ids.nama.text = user[3] or ""
            self.ids.alamat.text = user[4] or ""
            self.ids.hp.text = user[5] or ""

    def update_user(self):

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        UPDATE users
        SET nama=%s,
            alamat=%s,
            no_hp=%s
        WHERE id=%s
        """

        cursor.execute(query, (
            self.ids.nama.text,
            self.ids.alamat.text,
            self.ids.hp.text,
            self.ids.id_user.text
        ))

        conn.commit()

        if cursor.rowcount > 0:
            show_popup("Sukses", "Profil berhasil diupdate")
        else:
            show_popup("Info", "Tidak ada perubahan")

        conn.close()


# =====================================
# LAHAN
# =====================================

class LahanScreen(Screen):

    def kembali(self):
        self.manager.current = "dashboard"

    def clear_form(self):

        self.ids.id_lahan.text = ""
        self.ids.nama_lahan.text = ""
        self.ids.lokasi.text = ""
        self.ids.luas.text = ""
        self.ids.tanaman.text = ""

    def tambah_lahan(self):

        global current_user_id

        nama = self.ids.nama_lahan.text
        lokasi = self.ids.lokasi.text
        luas = self.ids.luas.text
        tanaman = self.ids.tanaman.text

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        INSERT INTO lahan
        (user_id, nama_lahan, lokasi, luas, jenis_tanaman)
        VALUES (%s,%s,%s,%s,%s)
        """

        cursor.execute(query, (
            current_user_id,
            nama,
            lokasi,
            luas,
            tanaman
        ))

        conn.commit()
        conn.close()

        show_popup("Sukses", "Lahan berhasil ditambah")

        self.clear_form()
        self.tampil_lahan()

    def tampil_lahan(self):

        global current_user_id

        keyword = self.ids.search.text

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        SELECT * FROM lahan
        WHERE user_id=%s
        AND nama_lahan LIKE %s
        """

        cursor.execute(query, (
            current_user_id,
            '%' + keyword + '%'
        ))

        data = cursor.fetchall()

        hasil = ""

        for row in data:

            hasil += f"""
ID : {row[0]}
Nama : {row[2]}
Lokasi : {row[3]}
Luas : {row[4]}
Tanaman : {row[5]}
=========================
"""

        self.ids.hasil_lahan.text = hasil

        conn.close()

    def update_lahan(self):

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        UPDATE lahan
        SET nama_lahan=%s,
            lokasi=%s,
            luas=%s,
            jenis_tanaman=%s
        WHERE id=%s
        """

        cursor.execute(query, (
            self.ids.nama_lahan.text,
            self.ids.lokasi.text,
            self.ids.luas.text,
            self.ids.tanaman.text,
            self.ids.id_lahan.text
        ))

        conn.commit()
        conn.close()

        show_popup("Sukses", "Lahan berhasil diupdate")

        self.tampil_lahan()

    def hapus_lahan(self):

        conn = connect_db()
        cursor = conn.cursor()

        query = "DELETE FROM lahan WHERE id=%s"

        cursor.execute(query, (
            self.ids.id_lahan.text,
        ))

        conn.commit()
        conn.close()

        show_popup("Sukses", "Lahan berhasil dihapus")

        self.clear_form()
        self.tampil_lahan()


# =====================================
# KEGIATAN
# =====================================

class KegiatanScreen(Screen):

    def kembali(self):
        self.manager.current = "dashboard"

    def show_date_picker(self):

        date_dialog = MDDatePicker()
        date_dialog.bind(on_save=self.set_date)
        date_dialog.open()

    def set_date(self, instance, value, date_range):

        self.ids.tanggal.text = str(value)

    def tambah_kegiatan(self):

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        INSERT INTO kegiatan
        (lahan_id, jenis_kegiatan, tanggal, catatan)
        VALUES (%s,%s,%s,%s)
        """

        cursor.execute(query, (
            self.ids.lahan_id.text,
            self.ids.jenis.text,
            self.ids.tanggal.text,
            self.ids.catatan.text
        ))

        conn.commit()
        conn.close()

        show_popup("Sukses", "Kegiatan berhasil ditambah")

        self.tampil_kegiatan()

    def tampil_kegiatan(self):

        conn = connect_db()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM kegiatan")

        data = cursor.fetchall()

        hasil = ""

        for row in data:

            hasil += f"""
ID : {row[0]}
Lahan ID : {row[1]}
Jenis : {row[2]}
Tanggal : {row[3]}
Catatan : {row[4]}
=========================
"""

        self.ids.hasil_kegiatan.text = hasil

        conn.close()

    def update_kegiatan(self):

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        UPDATE kegiatan
        SET jenis_kegiatan=%s,
            tanggal=%s,
            catatan=%s
        WHERE id=%s
        """

        cursor.execute(query, (
            self.ids.jenis.text,
            self.ids.tanggal.text,
            self.ids.catatan.text,
            self.ids.id_kegiatan.text
        ))

        conn.commit()
        conn.close()

        show_popup("Sukses", "Kegiatan berhasil diupdate")

        self.tampil_kegiatan()

    def hapus_kegiatan(self):

        conn = connect_db()
        cursor = conn.cursor()

        query = "DELETE FROM kegiatan WHERE id=%s"

        cursor.execute(query, (
            self.ids.id_kegiatan.text,
        ))

        conn.commit()
        conn.close()

        show_popup("Sukses", "Kegiatan berhasil dihapus")

        self.tampil_kegiatan()


# =====================================
# KONSULTASI
# =====================================

class KonsultasiScreen(Screen):

    def kembali(self):
        self.manager.current = "dashboard"

    def tambah_konsultasi(self):

        global current_user_id

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        INSERT INTO konsultasi
        (user_id, pertanyaan)
        VALUES (%s,%s)
        """

        cursor.execute(query, (
            current_user_id,
            self.ids.pertanyaan.text
        ))

        conn.commit()
        conn.close()

        show_popup("Sukses", "Konsultasi berhasil ditambah")

        self.tampil_konsultasi()

    def tampil_konsultasi(self):

        global current_user_id

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        SELECT * FROM konsultasi
        WHERE user_id=%s
        """

        cursor.execute(query, (current_user_id,))

        data = cursor.fetchall()

        hasil = ""

        for row in data:

            hasil += f"""
ID : {row[0]}
Pertanyaan : {row[2]}
Status : {row[3]}
=========================
"""

        self.ids.hasil_konsultasi.text = hasil

        conn.close()

    def update_status(self):

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        UPDATE konsultasi
        SET status=%s
        WHERE id=%s
        """

        cursor.execute(query, (
            self.ids.status_baru.text,
            self.ids.id_konsultasi.text
        ))

        conn.commit()
        conn.close()

        show_popup("Sukses", "Status berhasil diupdate")

        self.tampil_konsultasi()

    def hapus_konsultasi(self):

        conn = connect_db()
        cursor = conn.cursor()

        query = "DELETE FROM konsultasi WHERE id=%s"

        cursor.execute(query, (
            self.ids.id_konsultasi.text,
        ))

        conn.commit()
        conn.close()

        show_popup("Sukses", "Konsultasi berhasil dihapus")

        self.tampil_konsultasi()


# =====================================
# WINDOW MANAGER
# =====================================

class WindowManager(ScreenManager):
    pass


# =====================================
# APP
# =====================================

class PertanianApp(MDApp):

    def build(self):

        self.theme_cls.primary_palette = "Green"

        return Builder.load_file("main.kv")


if __name__ == "__main__":
    PertanianApp().run()